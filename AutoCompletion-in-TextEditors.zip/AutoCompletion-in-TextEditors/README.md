# Auto Complete System on Web using NLP and Python

#### I always want to know how our keyboard can predict the next word.
#### So I've tried to make an "Autocomplete System using NLP (Natural Language Processing) and Python. 
#### I've used Flask for making it on the web and NLP (N-grams) concept and a text file dataset from Kaggle to Machine Learning.

Web template that I've found online:  https://colorlib.com/wp/free-css3-html5-search-form-examples/

### YouTube Link:- https://www.youtube.com/watch?v=aB8PKCp6ftg
