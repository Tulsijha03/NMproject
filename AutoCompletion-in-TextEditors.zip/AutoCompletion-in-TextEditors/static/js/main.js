

/* 
Adiciona/Remove a classe 'floating-aberto', 
executando o efeito no menu flutuante
*/ 
